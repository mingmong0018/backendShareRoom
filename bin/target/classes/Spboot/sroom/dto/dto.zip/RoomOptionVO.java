package Spboot.sroom.dto;

import lombok.Data;

@Data
public class RoomOptionVO {
	private int room_id;
	private int option_id;
	private String option_group;
	private String option_name;
}
