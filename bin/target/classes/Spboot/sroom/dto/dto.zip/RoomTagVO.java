package Spboot.sroom.dto;

import lombok.Data;

@Data
public class RoomTagVO {
	private int room_id;
	private String tag_content;
}
