package Spboot.sroom.dto;

import lombok.Data;

@Data
public class WishListVO {
	private int wish_id;	
	private String mem_id;
	private int room_id;
}
